package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import eu.avalanche7.PermissionNode;
import eu.avalanche7.datastore.DataStoreManager;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class ListCommand {
    private final BetterChunkLoader instance;

    public ListCommand(BetterChunkLoader instance) {
        this.instance = instance;
    }

    public boolean list(CommandSender sender, String label, String[] args) {
        if (args.length < 2) {
            if (sender instanceof Player) {
                sender.sendMessage(ChatColor.YELLOW + "Usage:");
                sender.sendMessage(ChatColor.AQUA + "/" + label + " list own" + ChatColor.GRAY + " - show your chunk loaders");
                sender.sendMessage(ChatColor.AQUA + "/" + label + " list <Player>" + ChatColor.GRAY + " - show chunk loaders of a player");
                sender.sendMessage(ChatColor.AQUA + "/" + label + " list all" + ChatColor.GRAY + " - list all chunk loaders");
            } else {
                sender.sendMessage(ChatColor.RED + "This command must be run by a player.");
            }
            return false;
        }

        int page = 1;
        if (args.length == 3) {
            try {
                page = Integer.parseInt(args[2]);
                if (page < 1) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "Invalid page number.");
                return false;
            }
        }

        if (args[1].equalsIgnoreCase("all")) {
            if (!sender.hasPermission(PermissionNode.COMMAND_LIST_OTHER)) {
                sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
                return false;
            }
            List<CChunkLoader> allLoaders = DataStoreManager.getDataStore().getChunkLoaders();
            return printChunkLoadersList(allLoaders, sender, page);
        }

        String playerName = args[1];
        if (playerName.equalsIgnoreCase("own")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "This command must be run by a player.");
                return false;
            }
            playerName = sender.getName();
        }

        if (sender.getName().equalsIgnoreCase(playerName)) {
            if (!sender.hasPermission(PermissionNode.COMMAND_LIST_OWN)) {
                sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
                return false;
            }
        } else if (!sender.hasPermission(PermissionNode.COMMAND_LIST_OTHER)) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            return false;
        }

        OfflinePlayer targetPlayer = this.instance.getServer().getOfflinePlayer(playerName);
        if (targetPlayer == null || !targetPlayer.hasPlayedBefore()) {
            sender.sendMessage(ChatColor.RED + "Player not found or never joined.");
            return false;
        }

        List<CChunkLoader> clList = DataStoreManager.getDataStore().getChunkLoaders(targetPlayer.getUniqueId());
        if (clList == null || clList.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "This player doesn't have any chunk loaders.");
            return false;
        }

        return printChunkLoadersList(clList, sender, page);
    }

    private boolean printChunkLoadersList(List<CChunkLoader> clList, CommandSender sender, int page) {
        int total = clList.size();
        int perPage = 5;
        int pages = (int) Math.ceil(total / (double) perPage);
        if (page > pages) {
            sender.sendMessage(ChatColor.RED + "Page out of range. Max pages: " + pages);
            return false;
        }

        sender.sendMessage(ChatColor.GOLD + "== Chunk Loaders List (" + page + "/" + pages + ") ==");

        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, total);
        for (int i = start; i < end; i++) {
            CChunkLoader loader = clList.get(i);
            sender.sendMessage(ChatColor.YELLOW + "- " + loader.getOwnerName() +
                    " | " + loader.sizeX() +
                    " | " + loader.getLoc().toString() +
                    " | AlwaysOn: " + (loader.isAlwaysOn() ? "Yes" : "No"));
        }
        return true;
    }
}
