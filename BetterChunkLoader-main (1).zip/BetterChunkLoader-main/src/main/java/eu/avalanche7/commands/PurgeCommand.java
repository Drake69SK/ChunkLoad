package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import eu.avalanche7.PermissionNode;
import eu.avalanche7.datastore.DataStoreManager;
import eu.avalanche7.datastore.IDataStore;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public class PurgeCommand {
	private final BetterChunkLoader instance;

	public PurgeCommand(BetterChunkLoader instance) {
		this.instance = instance;
	}

	public boolean purge(CommandSender sender) {
		if (!sender.hasPermission(PermissionNode.COMMAND_PURGE)) {
			sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
			return false;
		}

		IDataStore dataStore = DataStoreManager.getDataStore();
		List<CChunkLoader> allLoaders = new ArrayList<>(dataStore.getChunkLoaders());

		int removed = 0;
		for (CChunkLoader cl : allLoaders) {
			if (!cl.blockCheck()) {
				dataStore.removeChunkLoader(cl);
				removed++;
			}
		}

		sender.sendMessage(ChatColor.GOLD + "Removed " + removed + " invalid chunk loader(s).");
		return true;
	}
}
