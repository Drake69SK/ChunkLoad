package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.PermissionNode;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class ReloadCommand {
	private final BetterChunkLoader instance;

	public ReloadCommand(BetterChunkLoader instance) {
		this.instance = instance;
	}

	public boolean reload(CommandSender sender) {
		if (!sender.hasPermission(PermissionNode.COMMAND_ADMIN)) {
			sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
			return false;
		}

		String pluginName = instance.getDescription().getName();

		sender.sendMessage(ChatColor.YELLOW + "Reloading " + pluginName + "...");
		instance.getLogger().info(sender.getName() + " requested a reload of " + pluginName);

		Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
		if (plugin != null) {
			Bukkit.getPluginManager().disablePlugin(plugin);
			Bukkit.getPluginManager().enablePlugin(plugin);
			sender.sendMessage(ChatColor.GREEN + pluginName + " has been reloaded.");
		} else {
			sender.sendMessage(ChatColor.RED + "Plugin not found. Reload failed.");
		}

		return true;
	}
}
