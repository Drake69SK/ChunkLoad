package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import eu.avalanche7.PermissionNode;
import eu.avalanche7.datastore.DataStoreManager;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import java.util.List;

public class DeleteCommand {
    private final BetterChunkLoader instance;

    public DeleteCommand(BetterChunkLoader instance) {
        this.instance = instance;
    }

    public boolean delete(CommandSender sender, String label, String[] args) {
        String usage = ChatColor.YELLOW + "Usage: /" + label + " delete (PlayerName)";

        if (!sender.hasPermission(PermissionNode.COMMAND_DELETE)) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            return false;
        }

        if (args.length < 2) {
            sender.sendMessage(usage);
            return false;
        }

        String playerName = args[1];
        OfflinePlayer target = instance.getServer().getOfflinePlayer(playerName);

        // Check if player exists
        if (target == null || (!target.isOnline() && !target.hasPlayedBefore())) {
            sender.sendMessage(ChatColor.RED + "Player \"" + playerName + "\" not found or never joined.");
            return false;
        }

        List<CChunkLoader> clList = DataStoreManager.getDataStore().getChunkLoaders(target.getUniqueId());

        if (clList == null || clList.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "This player doesn't have any chunk loaders.");
            return false;
        }

        DataStoreManager.getDataStore().removeChunkLoaders(target.getUniqueId());

        sender.sendMessage(ChatColor.GREEN + "All chunk loaders placed by " + target.getName() + " have been removed.");
        instance.getLogger().info(sender.getName() + " deleted all chunk loaders placed by " + target.getName());

        return true;
    }
}
