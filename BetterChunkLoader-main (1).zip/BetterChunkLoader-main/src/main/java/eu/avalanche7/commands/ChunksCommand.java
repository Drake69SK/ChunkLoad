package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.PermissionNode;
import eu.avalanche7.datastore.DataStoreManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import static eu.avalanche7.CommandExec.chunksInfo;

//public class ChunksCommand {
   // private BetterChunkLoader instance;

   // public ChunksCommand(BetterChunkLoader instance) {
       // this.instance = instance;
   // }

    //public boolean chunks(CommandSender sender, String label, String[] args) {
       // Integer amount;
       // String usage = "Usage: /" + label + " chunks (add|set) (PlayerName) (alwayson|onlineonly) (amount)";
       // if (args.length < 5) {
           // sender.sendMessage(chunksInfo((OfflinePlayer)sender));
           // return false;
       // }
        //if (!sender.hasPermission(PermissionNode.COMMAND_CHUNKS)) {
            //sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            //return false;
       // }
       // OfflinePlayer player = Bukkit.getOfflinePlayer(args[2]);
        //if (player == null) {
           // sender.sendMessage(args[2] + " is not a valid player name\n" + usage);
            //return false;
       // }
       // try {
            //amount = Integer.valueOf(args[4]);
       // } catch (NumberFormatException e) {
            //sender.sendMessage("Invalid argument " + args[4] + "\n" + usage);
            //return false;
        //}
        //sender.sendMessage(chunksInfo(player));
        //if (args[1].equalsIgnoreCase("add")) {
            //if (sender.hasPermission(PermissionNode.COMMAND_CHUNKS_ADD)) {
                //if (args[3].equalsIgnoreCase("alwayson")) {
                   // DataStoreManager.getDataStore().addAlwaysOnChunksLimit(player.getUniqueId(), amount.intValue());
                   // sender.sendMessage("Added " + amount + " always-on chunks to " + player.getName());
               // } else if (args[3].equalsIgnoreCase("onlineonly")) {
                   // DataStoreManager.getDataStore().addOnlineOnlyChunksLimit(player.getUniqueId(), amount.intValue());
                    //sender.sendMessage("Added " + amount + " online-only chunks to " + player.getName());
                //} else {
                   // sender.sendMessage("Invalid argument " + args[3] + "\n" + usage);
                   // return false;
               // }
          //  } else {
               // sender.sendMessage("You do not have permission to use this command.");
                //return false;
           // }
       // } else if (args[1].equalsIgnoreCase("set")) {
            //if (sender.hasPermission(PermissionNode.COMMAND_CHUNKS_SET)) {
                //if (amount.intValue() < 0) {
                   // sender.sendMessage("Invalid argument " + args[4] + "\n" + usage);
                   // return false;
              //  }
               // if (args[3].equalsIgnoreCase("alwayson")) {
                    //DataStoreManager.getDataStore().setAlwaysOnChunksLimit(player.getUniqueId(), amount.intValue());
                   // sender.sendMessage("Set " + amount + " always-on chunks to " + player.getName());
               // } else if (args[3].equalsIgnoreCase("onlineonly")) {
                   // DataStoreManager.getDataStore().setOnlineOnlyChunksLimit(player.getUniqueId(), amount.intValue());
                   // sender.sendMessage("Set " + amount + " online-only chunks to " + player.getName());
               // } else {
                    //sender.sendMessage("Invalid argument " + args[3] + "\n" + usage);
                    //return false;
               // }
           // } else {
               // sender.sendMessage("You do not have permission to use this command.");
                //return false;
           // }
        //} else {
            //sender.sendMessage("Invalid argument " + args[1] + "\n" + usage);
           // return false;
      //  }
       // return true;
   // }
//}

public class ChunksCommand {

    private final BetterChunkLoader instance;

    public ChunksCommand(BetterChunkLoader instance) {
        this.instance = instance;
    }

    public boolean chunks(CommandSender sender, String label, String[] args) {
        String usage = ChatColor.YELLOW + "Usage: /" + label + " chunks (add|set) (PlayerName) (alwayson|onlineonly) (amount)";

        // Permission check for base command
        if (!sender.hasPermission(PermissionNode.COMMAND_CHUNKS)) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            return false;
        }

        // Basic argument length check
        if (args.length < 5) {
            sender.sendMessage(usage);
            return false;
        }

        String action = args[1].toLowerCase();
        String playerName = args[2];
        String type = args[3].toLowerCase();
        String amountStr = args[4];

        OfflinePlayer target = Bukkit.getOfflinePlayer(playerName);

        if (target == null || (!target.isOnline() && !target.hasPlayedBefore())) {
            sender.sendMessage(ChatColor.RED + "Player \"" + playerName + "\" is unknown or has never joined.");
            sender.sendMessage(usage);
            return false;
        }

        int amount;
        try {
            amount = Integer.parseInt(amountStr);
            if (amount < 0) {
                sender.sendMessage(ChatColor.RED + "Chunk amount must be non-negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Invalid amount: \"" + amountStr + "\"");
            sender.sendMessage(usage);
            return false;
        }

        // Show player's current chunk info
        sender.sendMessage(chunksInfo(target));

        // Handle 'add' and 'set' actions
        switch (action) {
            case "add":
                if (!sender.hasPermission(PermissionNode.COMMAND_CHUNKS_ADD)) {
                    sender.sendMessage(ChatColor.RED + "You do not have permission to add chunks.");
                    return false;
                }
                return handleAdd(type, target, amount, sender);

            case "set":
                if (!sender.hasPermission(PermissionNode.COMMAND_CHUNKS_SET)) {
                    sender.sendMessage(ChatColor.RED + "You do not have permission to set chunks.");
                    return false;
                }
                return handleSet(type, target, amount, sender);

            default:
                sender.sendMessage(ChatColor.RED + "Invalid action: \"" + action + "\"");
                sender.sendMessage(usage);
                return false;
        }
    }

    private boolean handleAdd(String type, OfflinePlayer player, int amount, CommandSender sender) {
        switch (type) {
            case "alwayson":
                DataStoreManager.getDataStore().addAlwaysOnChunksLimit(player.getUniqueId(), amount);
                sender.sendMessage(ChatColor.GREEN + "Added " + amount + " always-on chunks to " + player.getName());
                return true;
            case "onlineonly":
                DataStoreManager.getDataStore().addOnlineOnlyChunksLimit(player.getUniqueId(), amount);
                sender.sendMessage(ChatColor.GREEN + "Added " + amount + " online-only chunks to " + player.getName());
                return true;
            default:
                sender.sendMessage(ChatColor.RED + "Invalid chunk type: \"" + type + "\" (must be 'alwayson' or 'onlineonly')");
                return false;
        }
    }

    private boolean handleSet(String type, OfflinePlayer player, int amount, CommandSender sender) {
        switch (type) {
            case "alwayson":
                DataStoreManager.getDataStore().setAlwaysOnChunksLimit(player.getUniqueId(), amount);
                sender.sendMessage(ChatColor.GREEN + "Set " + amount + " always-on chunks for " + player.getName());
                return true;
            case "onlineonly":
                DataStoreManager.getDataStore().setOnlineOnlyChunksLimit(player.getUniqueId(), amount);
                sender.sendMessage(ChatColor.GREEN + "Set " + amount + " online-only chunks for " + player.getName());
                return true;
            default:
                sender.sendMessage(ChatColor.RED + "Invalid chunk type: \"" + type + "\" (must be 'alwayson' or 'onlineonly')");
                return false;
        }
    }
}

