package eu.avalanche7.commands;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import eu.avalanche7.PermissionNode;
import eu.avalanche7.datastore.DataStoreManager;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class InfoCommand {
    private final BetterChunkLoader instance;

    public InfoCommand(BetterChunkLoader instance) {
        this.instance = instance;
    }

    public boolean info(CommandSender sender) {
        if (!sender.hasPermission(PermissionNode.COMMAND_INFO)) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            return false;
        }

        List<CChunkLoader> chunkLoaders = DataStoreManager.getDataStore().getChunkLoaders();
        if (chunkLoaders == null || chunkLoaders.isEmpty()) {
            sender.sendMessage(ChatColor.YELLOW + "No chunk loader statistics available.");
            return true;
        }

        int alwaysOnLoaders = 0;
        int onlineOnlyLoaders = 0;
        int alwaysOnChunks = 0;
        int onlineOnlyChunks = 0;
        int maxChunksCount = 0;
        int players = 0;

        UUID maxChunksPlayer = null;
        HashMap<UUID, Integer> loadedChunksForPlayer = new HashMap<UUID, Integer>();

        for (CChunkLoader chunkLoader : chunkLoaders) {
            int size = chunkLoader.size();
            UUID owner = chunkLoader.getOwner();

            if (chunkLoader.isAlwaysOn()) {
                alwaysOnLoaders++;
                alwaysOnChunks += size;
            } else {
                onlineOnlyLoaders++;
                onlineOnlyChunks += size;
            }

            Integer current = loadedChunksForPlayer.get(owner);
            if (current == null) {
                current = 0;
            }
            loadedChunksForPlayer.put(owner, current + size);
        }

        // Remove admin UUID from stats
        loadedChunksForPlayer.remove(CChunkLoader.adminUUID);

        players = loadedChunksForPlayer.size();

        for (Map.Entry<UUID, Integer> entry : loadedChunksForPlayer.entrySet()) {
            if (entry.getValue() > maxChunksCount) {
                maxChunksCount = entry.getValue();
                maxChunksPlayer = entry.getKey();
            }
        }

        String maxChunksPlayerName = "N/A";
        if (maxChunksPlayer != null) {
            OfflinePlayer offlinePlayer = instance.getServer().getOfflinePlayer(maxChunksPlayer);
            if (offlinePlayer != null && (offlinePlayer.isOnline() || offlinePlayer.hasPlayedBefore())) {
                maxChunksPlayerName = offlinePlayer.getName();
            }
        }

        sender.sendMessage(ChatColor.GOLD + "=== BetterChunkLoader Statistics ===");
        sender.sendMessage(ChatColor.WHITE + "OnlineOnly Loaders: " + onlineOnlyLoaders + " (" + onlineOnlyChunks + " chunks)");
        sender.sendMessage(ChatColor.WHITE + "AlwaysOn Loaders: " + alwaysOnLoaders + " (" + alwaysOnChunks + " chunks)");
        sender.sendMessage(ChatColor.WHITE + "Players using loaders: " + players);
        sender.sendMessage(ChatColor.WHITE + "Top Player: " + maxChunksPlayerName + " (" + maxChunksCount + " chunks)");

        return true;
    }
}
