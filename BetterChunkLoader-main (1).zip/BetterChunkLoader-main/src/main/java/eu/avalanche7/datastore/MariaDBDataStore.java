package eu.avalanche7.datastore;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import org.apache.commons.lang.StringUtils;

import java.sql.*;
import java.util.*;

public class MariaDBDataStore extends AHashMapDataStore {
    private Connection dbConnection;

    @Override
    public String getName() {
        return "MariaDB";
    }

    @Override
    public void load() {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            BetterChunkLoader.instance().getLogger().warning("MariaDB driver not found.");
            throw new RuntimeException(e);
        }

        try {
            refreshConnection();
        } catch (SQLException e) {
            BetterChunkLoader.instance().getLogger().warning("Unable to connect to MariaDB.");
            throw new RuntimeException(e);
        }

        this.chunkLoaders = new HashMap<>();
        this.playersData = new HashMap<>();

        try (Statement stmt = dbConnection.createStatement()) {
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS bcl_chunkloaders (loc VARCHAR(50) PRIMARY KEY, r TINYINT UNSIGNED, owner BINARY(16), date BIGINT, aon TINYINT)");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS bcl_playersdata (pid BINARY(16) PRIMARY KEY, alwayson SMALLINT UNSIGNED, onlineonly SMALLINT UNSIGNED)");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create tables", e);
        }

        loadChunkLoaders();
        loadPlayerData();
    }

    private void loadChunkLoaders() {
        try (Statement stmt = dbConnection.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM bcl_chunkloaders")) {
            while (rs.next()) {
                CChunkLoader cl = new CChunkLoader(
                        rs.getString("loc"),
                        rs.getByte("r"),
                        toUUID(rs.getBytes("owner")),
                        new Date(rs.getLong("date")),
                        rs.getBoolean("aon")
                );

                chunkLoaders.computeIfAbsent(cl.getWorldName(), k -> new ArrayList<>()).add(cl);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load chunk loaders from MariaDB", e);
        }
    }

    private void loadPlayerData() {
        try (Statement stmt = dbConnection.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM bcl_playersdata")) {
            while (rs.next()) {
                PlayerData pd = new PlayerData(
                        toUUID(rs.getBytes("pid")),
                        rs.getInt("alwayson"),
                        rs.getInt("onlineonly")
                );
                playersData.put(pd.getPlayerId(), pd);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load player data from MariaDB", e);
        }
    }

    @Override
    public void addChunkLoader(CChunkLoader chunkLoader) {
        super.addChunkLoader(chunkLoader);
        try (PreparedStatement ps = dbConnection.prepareStatement(
                "REPLACE INTO bcl_chunkloaders (loc, r, owner, date, aon) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, chunkLoader.getLocationString());
            ps.setByte(2, chunkLoader.getRange());
            ps.setBytes(3, uuidToBytes(chunkLoader.getOwner()));
            ps.setLong(4, chunkLoader.getCreationDate().getTime());
            ps.setBoolean(5, chunkLoader.isAlwaysOn());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void removeChunkLoader(CChunkLoader chunkLoader) {
        super.removeChunkLoader(chunkLoader);
        try (PreparedStatement ps = dbConnection.prepareStatement(
                "DELETE FROM bcl_chunkloaders WHERE loc = ?")) {
            ps.setString(1, chunkLoader.getLocationString());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void removeChunkLoaders(UUID ownerId) {
        super.removeChunkLoaders(ownerId);
        try (PreparedStatement ps = dbConnection.prepareStatement(
                "DELETE FROM bcl_chunkloaders WHERE owner = ?")) {
            ps.setBytes(1, uuidToBytes(ownerId));
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void changeChunkLoaderRange(CChunkLoader chunkLoader, byte range) {
        super.changeChunkLoaderRange(chunkLoader, range);
        try (PreparedStatement ps = dbConnection.prepareStatement(
                "UPDATE bcl_chunkloaders SET r = ? WHERE loc = ?")) {
            ps.setByte(1, range);
            ps.setString(2, chunkLoader.getLocationString());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updatePlayerChunks(UUID playerId, int alwaysOn, int onlineOnly) {
        try (PreparedStatement ps = dbConnection.prepareStatement(
                "REPLACE INTO bcl_playersdata (pid, alwayson, onlineonly) VALUES (?, ?, ?)")) {
            ps.setBytes(1, uuidToBytes(playerId));
            ps.setInt(2, alwaysOn);
            ps.setInt(3, onlineOnly);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setAlwaysOnChunksLimit(UUID playerId, int amount) {
        super.setAlwaysOnChunksLimit(playerId, amount);
        int onlineOnly = getPlayerData(playerId).getOnlineOnlyChunksAmount();
        updatePlayerChunks(playerId, amount, onlineOnly);
    }

    @Override
    public void setOnlineOnlyChunksLimit(UUID playerId, int amount) {
        super.setOnlineOnlyChunksLimit(playerId, amount);
        int alwaysOn = getPlayerData(playerId).getAlwaysOnChunksAmount();
        updatePlayerChunks(playerId, alwaysOn, amount);
    }

    @Override
    public void addAlwaysOnChunksLimit(UUID playerId, int amount) {
        int updated = getPlayerData(playerId).getAlwaysOnChunksAmount() + amount;
        setAlwaysOnChunksLimit(playerId, updated);
    }

    @Override
    public void addOnlineOnlyChunksLimit(UUID playerId, int amount) {
        int updated = getPlayerData(playerId).getOnlineOnlyChunksAmount() + amount;
        setOnlineOnlyChunksLimit(playerId, updated);
    }

    private void refreshConnection() throws SQLException {
        if (dbConnection == null || dbConnection.isClosed()) {
            Properties props = new Properties();
            props.put("user", BetterChunkLoader.instance().config().mySqlUsername);
            props.put("password", BetterChunkLoader.instance().config().mySqlPassword);
            dbConnection = DriverManager.getConnection(
                    "jdbc:mariadb://" + BetterChunkLoader.instance().config().mySqlHostname +
                            ":" + BetterChunkLoader.instance().config().mySqlPort +
                            "/" + BetterChunkLoader.instance().config().mySqlDatabase + "?useUnicode=true&characterEncoding=utf8",
                    props
            );
        }
    }

    private static byte[] uuidToBytes(UUID uuid) {
        byte[] bytes = new byte[16];
        long most = uuid.getMostSignificantBits();
        long least = uuid.getLeastSignificantBits();
        for (int i = 0; i < 8; i++) bytes[i] = (byte) (most >>> (8 * (7 - i)));
        for (int i = 0; i < 8; i++) bytes[8 + i] = (byte) (least >>> (8 * (7 - i)));
        return bytes;
    }

    public static UUID toUUID(byte[] bytes) {
        if (bytes == null || bytes.length != 16) throw new IllegalArgumentException("Invalid UUID byte array");
        long most = 0;
        long least = 0;
        for (int i = 0; i < 8; i++) most = (most << 8) | (bytes[i] & 0xff);
        for (int i = 8; i < 16; i++) least = (least << 8) | (bytes[i] & 0xff);
        return new UUID(most, least);
    }

    public static String UUIDtoHexString(UUID uuid) {
        return "0x" + StringUtils.leftPad(Long.toHexString(uuid.getMostSignificantBits()), 16, "0")
                     + StringUtils.leftPad(Long.toHexString(uuid.getLeastSignificantBits()), 16, "0");
    }
}
