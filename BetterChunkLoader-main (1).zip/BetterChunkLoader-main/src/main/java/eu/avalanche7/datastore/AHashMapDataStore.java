package eu.avalanche7.datastore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import eu.avalanche7.BlockLocation;
import eu.avalanche7.CChunkLoader;
import net.kaikk.mc.bcl.forgelib.BCLForgeLib;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.World;

public abstract class AHashMapDataStore implements IDataStore {
	protected Map<String, List<CChunkLoader>> chunkLoaders = new HashMap<String, List<CChunkLoader>>();
	protected Map<UUID, PlayerData> playersData = new HashMap<UUID, PlayerData>();

	@Override
	public List<CChunkLoader> getChunkLoaders() {
		List<CChunkLoader> all = new ArrayList<CChunkLoader>();
		for (List<CChunkLoader> clList : this.chunkLoaders.values()) {
			all.addAll(clList);
		}
		return all;
	}

	@Override
	public List<CChunkLoader> getChunkLoaders(String worldName) {
		List<CChunkLoader> list = this.chunkLoaders.get(worldName);
		return list != null ? list : Collections.<CChunkLoader>emptyList();
	}

	@Override
	public List<CChunkLoader> getChunkLoadersAt(String worldName, int chunkX, int chunkZ) {
		List<CChunkLoader> result = new ArrayList<CChunkLoader>();
		for (CChunkLoader cl : getChunkLoaders(worldName)) {
			if (cl.getChunkX() == chunkX && cl.getChunkZ() == chunkZ) {
				result.add(cl);
			}
		}
		return result;
	}

	@Override
	public List<CChunkLoader> getChunkLoaders(UUID ownerId) {
		List<CChunkLoader> result = new ArrayList<CChunkLoader>();
		for (CChunkLoader cl : getChunkLoaders()) {
			if (cl.getOwner().equals(ownerId)) {
				result.add(cl);
			}
		}
		return result;
	}

	@Override
	public CChunkLoader getChunkLoaderAt(BlockLocation loc) {
		for (CChunkLoader cl : getChunkLoaders(loc.getWorldName())) {
			if (cl.getLoc().equals(loc)) {
				return cl;
			}
		}
		return null;
	}

	@Override
	public void addChunkLoader(CChunkLoader chunkLoader) {
		String world = chunkLoader.getWorldName();
		List<CChunkLoader> clList = this.chunkLoaders.get(world);
		if (clList == null) {
			clList = new ArrayList<CChunkLoader>();
			this.chunkLoaders.put(world, clList);
		}
		clList.add(chunkLoader);

		// Particle effect for placement
		Location location = chunkLoader.getLoc().getLocation();
		if (location != null && location.getWorld() != null) {
			location.getWorld().playEffect(location, Effect.MOBSPAWNER_FLAMES, 0);
		}

		if (chunkLoader.isLoadable()) {
			BCLForgeLib.instance().addChunkLoader(chunkLoader);
		}
	}

	@Override
	public void removeChunkLoader(CChunkLoader chunkLoader) {
		List<CChunkLoader> clList = this.chunkLoaders.get(chunkLoader.getWorldName());
		if (clList != null) {
			if (chunkLoader.blockCheck()) {
				Location location = chunkLoader.getLoc().getLocation();
				if (location != null && location.getWorld() != null) {
					location.getWorld().playEffect(location, Effect.POTION_BREAK, 0);
				}
			}
			clList.remove(chunkLoader);
			BCLForgeLib.instance().removeChunkLoader(chunkLoader);
		}
	}

	@Override
	public void removeChunkLoaders(UUID ownerId) {
		for (List<CChunkLoader> clList : this.chunkLoaders.values()) {
			clList.removeIf(cl -> cl.getOwner().equals(ownerId));
		}
	}

	@Override
	public void changeChunkLoaderRange(CChunkLoader cl, byte range) {
		if (cl.isLoadable()) {
			BCLForgeLib.instance().removeChunkLoader(cl);
		}
		cl.setRange(range);
		if (cl.isLoadable()) {
			BCLForgeLib.instance().addChunkLoader(cl);
		}
	}

	@Override
	public int getAlwaysOnFreeChunksAmount(UUID playerId) {
		int max = getPlayerData(playerId).getAlwaysOnChunksAmount();
		for (CChunkLoader cl : getChunkLoaders(playerId)) {
			if (cl.isAlwaysOn()) {
				max -= cl.size();
			}
		}
		return max;
	}

	@Override
	public int getOnlineOnlyFreeChunksAmount(UUID playerId) {
		int max = getPlayerData(playerId).getOnlineOnlyChunksAmount();
		for (CChunkLoader cl : getChunkLoaders(playerId)) {
			if (!cl.isAlwaysOn()) {
				max -= cl.size();
			}
		}
		return max;
	}

	@Override
	public void setAlwaysOnChunksLimit(UUID playerId, int amount) {
		getPlayerData(playerId).setAlwaysOnChunksAmount(amount);
	}

	@Override
	public void setOnlineOnlyChunksLimit(UUID playerId, int amount) {
		getPlayerData(playerId).setOnlineOnlyChunksAmount(amount);
	}

	@Override
	public void addAlwaysOnChunksLimit(UUID playerId, int amount) {
		PlayerData pd = getPlayerData(playerId);
		pd.setAlwaysOnChunksAmount(pd.getAlwaysOnChunksAmount() + amount);
	}

	@Override
	public void addOnlineOnlyChunksLimit(UUID playerId, int amount) {
		PlayerData pd = getPlayerData(playerId);
		pd.setOnlineOnlyChunksAmount(pd.getOnlineOnlyChunksAmount() + amount);
	}

	@Override
	public PlayerData getPlayerData(UUID playerId) {
		PlayerData pd = playersData.get(playerId);
		if (pd == null) {
			pd = new PlayerData(playerId);
			playersData.put(playerId, pd);
		}
		return pd;
	}

	@Override
	public List<PlayerData> getPlayersData() {
		return new ArrayList<PlayerData>(playersData.values());
	}
}
