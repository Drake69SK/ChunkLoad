package eu.avalanche7.datastore;

import eu.avalanche7.BetterChunkLoader;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.UUID;

@XmlRootElement(name = "player")
public class PlayerData {

	private UUID playerId;
	private int alwaysOnChunksAmount;
	private int onlineOnlyChunksAmount;

	/** Default constructor required for XML binding */
	public PlayerData() {
		this.alwaysOnChunksAmount = BetterChunkLoader.instance().config().defaultChunksAmountAlwaysOn;
		this.onlineOnlyChunksAmount = BetterChunkLoader.instance().config().defaultChunksAmountOnlineOnly;
	}

	public PlayerData(UUID playerId) {
		this.playerId = playerId;
		this.alwaysOnChunksAmount = BetterChunkLoader.instance().config().defaultChunksAmountAlwaysOn;
		this.onlineOnlyChunksAmount = BetterChunkLoader.instance().config().defaultChunksAmountOnlineOnly;
	}

	public PlayerData(UUID playerId, int alwaysOnChunksAmount, int onlineOnlyChunksAmount) {
		this.playerId = playerId;
		this.alwaysOnChunksAmount = alwaysOnChunksAmount;
		this.onlineOnlyChunksAmount = onlineOnlyChunksAmount;
	}

	@XmlAttribute(name = "id")
	public UUID getPlayerId() {
		return playerId;
	}

	public void setPlayerId(UUID playerId) {
		this.playerId = playerId;
	}

	/** Total amount of always-on chunks this player can load */
	@XmlAttribute(name = "aon")
	public int getAlwaysOnChunksAmount() {
		return alwaysOnChunksAmount;
	}

	public void setAlwaysOnChunksAmount(int alwaysOnChunksAmount) {
		this.alwaysOnChunksAmount = alwaysOnChunksAmount;
	}

	/** Total amount of online-only chunks this player can load */
	@XmlAttribute(name = "oon")
	public int getOnlineOnlyChunksAmount() {
		return onlineOnlyChunksAmount;
	}

	public void setOnlineOnlyChunksAmount(int onlineOnlyChunksAmount) {
		this.onlineOnlyChunksAmount = onlineOnlyChunksAmount;
	}
}
