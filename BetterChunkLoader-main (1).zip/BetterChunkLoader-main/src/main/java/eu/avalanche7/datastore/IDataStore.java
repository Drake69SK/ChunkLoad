package eu.avalanche7.datastore;

import java.util.List;
import java.util.UUID;

import eu.avalanche7.BlockLocation;
import eu.avalanche7.CChunkLoader;

/** Interface for BetterChunkLoader's data store<br>
 * How to create custom data store:<br>
 * - Make a class that implements this interface<br>
 * - Call DataStoreManager.registerDataStore(name, class) during your plugin's onLoad()
 */
public interface IDataStore {

	/** Returns the data store name */
	String getName();

	/** Loads data from the datastore.
	 *  This is called while BCL is loading */
	void load();

	/** Get all chunk loaders */
	List<CChunkLoader> getChunkLoaders();

	/** Get chunk loaders for world name */
	List<CChunkLoader> getChunkLoaders(String worldName);

	/** Get chunk loaders at specified chunk */
	List<CChunkLoader> getChunkLoadersAt(String worldName, int chunkX, int chunkZ);

	/** Get chunk loaders owned by player */
	List<CChunkLoader> getChunkLoaders(UUID ownerId);

	/** Get chunk loader at specific block location */
	CChunkLoader getChunkLoaderAt(BlockLocation blockLocation);

	/** Add a new chunk loader */
	void addChunkLoader(CChunkLoader chunkLoader);

	/** Remove a specific chunk loader */
	void removeChunkLoader(CChunkLoader chunkLoader);

	/** Remove all chunk loaders of a player */
	void removeChunkLoaders(UUID ownerId);

	/** Change chunk loader range */
	void changeChunkLoaderRange(CChunkLoader chunkLoader, byte range);

	/** Free always-on chunks remaining for player */
	int getAlwaysOnFreeChunksAmount(UUID playerId);

	/** Free online-only chunks remaining for player */
	int getOnlineOnlyFreeChunksAmount(UUID playerId);

	/** Set limit of always-on chunks for player */
	void setAlwaysOnChunksLimit(UUID playerId, int amount);

	/** Set limit of online-only chunks for player */
	void setOnlineOnlyChunksLimit(UUID playerId, int amount);

	/** Add to limit of always-on chunks */
	void addAlwaysOnChunksLimit(UUID playerId, int amount);

	/** Add to limit of online-only chunks */
	void addOnlineOnlyChunksLimit(UUID playerId, int amount);

	/** Get player data */
	PlayerData getPlayerData(UUID playerId);

	/** Get data for all players */
	List<PlayerData> getPlayersData();
}
