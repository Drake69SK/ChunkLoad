package eu.avalanche7.datastore;

import eu.avalanche7.BetterChunkLoader;
import eu.avalanche7.CChunkLoader;
import org.apache.commons.lang.StringUtils;

import java.sql.*;
import java.util.*;

public class MySqlDataStore extends AHashMapDataStore {
	private Connection dbConnection;

	@Override
	public String getName() {
		return "MySQL";
	}

	@Override
	public void load() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // moderný MySQL driver
		} catch (ClassNotFoundException e) {
			BetterChunkLoader.instance().getLogger().warning("Unable to load MySQL database driver.");
			throw new RuntimeException(e);
		}

		try {
			refreshConnection();
		} catch (SQLException e) {
			BetterChunkLoader.instance().getLogger().warning("Unable to connect to MySQL database.");
			throw new RuntimeException(e);
		}

		try (Statement stmt = statement()) {
			stmt.executeUpdate("CREATE TABLE IF NOT EXISTS bcl_chunkloaders (" +
				"loc VARCHAR(50) NOT NULL, r TINYINT UNSIGNED NOT NULL, owner BINARY(16) NOT NULL, " +
				"date BIGINT NOT NULL, aon TINYINT(1) NOT NULL, UNIQUE KEY(loc))");

			stmt.executeUpdate("CREATE TABLE IF NOT EXISTS bcl_playersdata (" +
				"pid BINARY(16) NOT NULL, alwayson SMALLINT UNSIGNED NOT NULL, onlineonly SMALLINT UNSIGNED NOT NULL, " +
				"UNIQUE KEY(pid))");
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		this.chunkLoaders = new HashMap<>();
		this.playersData = new HashMap<>();

		try (ResultSet rs = statement().executeQuery("SELECT * FROM bcl_chunkloaders")) {
			while (rs.next()) {
				CChunkLoader cl = new CChunkLoader(
					rs.getString("loc"),
					rs.getByte("r"),
					toUUID(rs.getBytes("owner")),
					new Date(rs.getLong("date")),
					rs.getBoolean("aon")
				);
				this.chunkLoaders.computeIfAbsent(cl.getWorldName(), k -> new ArrayList<>()).add(cl);
			}
		} catch (SQLException e) {
			throw new RuntimeException("Couldn't read chunk loader data", e);
		}

		try (ResultSet rs = statement().executeQuery("SELECT * FROM bcl_playersdata")) {
			while (rs.next()) {
				PlayerData pd = new PlayerData(toUUID(rs.getBytes("pid")), rs.getInt("alwayson"), rs.getInt("onlineonly"));
				this.playersData.put(pd.getPlayerId(), pd);
			}
		} catch (SQLException e) {
			throw new RuntimeException("Couldn't read player data", e);
		}
	}

	@Override
	public void addChunkLoader(CChunkLoader cl) {
		super.addChunkLoader(cl);
		String sql = "REPLACE INTO bcl_chunkloaders VALUES (?, ?, UNHEX(?), ?, ?)";
		try (PreparedStatement ps = dbConnection.prepareStatement(sql)) {
			ps.setString(1, cl.getLocationString());
			ps.setByte(2, cl.getRange());
			ps.setString(3, UUIDtoHexString(cl.getOwner()));
			ps.setLong(4, cl.getCreationDate().getTime());
			ps.setBoolean(5, cl.isAlwaysOn());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void removeChunkLoader(CChunkLoader cl) {
		super.removeChunkLoader(cl);
		String sql = "DELETE FROM bcl_chunkloaders WHERE loc=? LIMIT 1";
		try (PreparedStatement ps = dbConnection.prepareStatement(sql)) {
			ps.setString(1, cl.getLocationString());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void removeChunkLoaders(UUID ownerId) {
		super.removeChunkLoaders(ownerId);
		String sql = "DELETE FROM bcl_chunkloaders WHERE owner=UNHEX(?)";
		try (PreparedStatement ps = dbConnection.prepareStatement(sql)) {
			ps.setString(1, UUIDtoHexString(ownerId));
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void changeChunkLoaderRange(CChunkLoader cl, byte range) {
		super.changeChunkLoaderRange(cl, range);
		String sql = "UPDATE bcl_chunkloaders SET r=? WHERE loc=? LIMIT 1";
		try (PreparedStatement ps = dbConnection.prepareStatement(sql)) {
			ps.setByte(1, range);
			ps.setString(2, cl.getLocationString());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setAlwaysOnChunksLimit(UUID playerId, int amount) {
		super.setAlwaysOnChunksLimit(playerId, amount);
		updatePlayerData(playerId, amount, BetterChunkLoader.instance().config().defaultChunksAmountOnlineOnly, true);
	}

	@Override
	public void setOnlineOnlyChunksLimit(UUID playerId, int amount) {
		super.setOnlineOnlyChunksLimit(playerId, amount);
		updatePlayerData(playerId, BetterChunkLoader.instance().config().defaultChunksAmountAlwaysOn, amount, true);
	}

	@Override
	public void addAlwaysOnChunksLimit(UUID playerId, int amount) {
		super.addAlwaysOnChunksLimit(playerId, amount);
		updatePlayerData(playerId, amount, BetterChunkLoader.instance().config().defaultChunksAmountOnlineOnly, false);
	}

	@Override
	public void addOnlineOnlyChunksLimit(UUID playerId, int amount) {
		super.addOnlineOnlyChunksLimit(playerId, amount);
		updatePlayerData(playerId, BetterChunkLoader.instance().config().defaultChunksAmountAlwaysOn, amount, false);
	}

	private void updatePlayerData(UUID uuid, int alwaysOn, int onlineOnly, boolean overwrite) {
		String sql = overwrite
			? "INSERT INTO bcl_playersdata VALUES (UNHEX(?), ?, ?) ON DUPLICATE KEY UPDATE alwayson=?, onlineonly=?"
			: "INSERT INTO bcl_playersdata VALUES (UNHEX(?), ?, ?) ON DUPLICATE KEY UPDATE alwayson=alwayson+?, onlineonly=onlineonly+?";
		try (PreparedStatement ps = dbConnection.prepareStatement(sql)) {
			ps.setString(1, UUIDtoHexString(uuid));
			ps.setInt(2, alwaysOn);
			ps.setInt(3, onlineOnly);
			ps.setInt(4, alwaysOn);
			ps.setInt(5, onlineOnly);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void refreshConnection() throws SQLException {
		if (this.dbConnection == null || this.dbConnection.isClosed()) {
			Properties props = new Properties();
			props.setProperty("user", BetterChunkLoader.instance().config().mySqlUsername);
			props.setProperty("password", BetterChunkLoader.instance().config().mySqlPassword);
			props.setProperty("autoReconnect", "true");
			this.dbConnection = DriverManager.getConnection(
				"jdbc:mysql://" + BetterChunkLoader.instance().config().mySqlHostname + ":" +
					BetterChunkLoader.instance().config().mySqlPort + "/" +
					BetterChunkLoader.instance().config().mySqlDatabase + "?useSSL=false&characterEncoding=utf8",
				props
			);
		}
	}

	private Statement statement() throws SQLException {
		refreshConnection();
		return this.dbConnection.createStatement();
	}

	public static UUID toUUID(byte[] bytes) {
		if (bytes.length != 16) throw new IllegalArgumentException();
		long msb = 0;
		long lsb = 0;
		for (int i = 0; i < 8; i++) msb = (msb << 8) | (bytes[i] & 0xff);
		for (int i = 8; i < 16; i++) lsb = (lsb << 8) | (bytes[i] & 0xff);
		return new UUID(msb, lsb);
	}

	public static String UUIDtoHexString(UUID uuid) {
		return StringUtils.leftPad(Long.toHexString(uuid.getMostSignificantBits()), 16, "0") +
			   StringUtils.leftPad(Long.toHexString(uuid.getLeastSignificantBits()), 16, "0");
	}
}
