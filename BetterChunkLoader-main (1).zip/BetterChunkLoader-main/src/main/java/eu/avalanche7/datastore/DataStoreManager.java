package eu.avalanche7.datastore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Data store manager<br>
 * See IDataStore interface if you want to implement your custom data store */
public final class DataStoreManager {
	private static Map<String, Class<? extends IDataStore>> dataStores = new HashMap<String, Class<? extends IDataStore>>();
	private static IDataStore dataStore;

	/** Register a new Data Store. This should be run at onLoad()<br>
	 * @param dataStoreId ID that identifies this data store <br>
	 * @param dataStoreClass a class that implements IDataStore */
	public static void registerDataStore(String dataStoreId, Class<? extends IDataStore> dataStoreClass) {
		dataStores.put(dataStoreId, dataStoreClass);
	}

	/** Unregisters the data store with the provided id */
	public static void unregisterDataStore(String dataStoreId) {
		dataStores.remove(dataStoreId);
	}

	/** List of registered data stores id */
	public static List<String> getAvailableDataStores() {
		return new ArrayList<String>(dataStores.keySet());
	}

	/** Sets and instantiate the data store */
	public static void setDataStoreInstance(String dataStoreId) {
		try {
			Class<? extends IDataStore> clazz = dataStores.get(dataStoreId);
			if (clazz == null) {
				throw new RuntimeException("Data store ID not found: " + dataStoreId);
			}
			dataStore = clazz.newInstance();
		} catch (Exception e) { // Java 7-compatible
			e.printStackTrace();
			throw new RuntimeException("Couldn't instantiate data store: " + dataStoreId);
		}
	}

	/** Gets current data store. Returns null if there isn't an instantiated data store */
	public static IDataStore getDataStore() {
		return dataStore;
	}

	/** Optionally force a data store instance (used in fallback configs) */
	public static void setDataStoreInstance(IDataStore store) {
		dataStore = store;
	}
}
