package eu.avalanche7.config;

import eu.avalanche7.BetterChunkLoader;
import org.bukkit.Material;

public class Config {
	public int maxHoursOffline;
	public int defaultChunksAmountAlwaysOn;
	public int defaultChunksAmountOnlineOnly;
	public String dataStore;

	public String mySqlHostname;
	public String mySqlPort;
	public String mySqlUsername;
	public String mySqlPassword;
	public String mySqlDatabase;

	public int alwaysOnBlockId;
	public int onlineOnlyBlockId;
	public int alwaysOnBlockData;
	public int onlineOnlyBlockData;

	public Config(BetterChunkLoader instance) {
		// Načítanie konfigurácie so zachovaním predvolených hodnôt
		instance.getConfig().options().copyDefaults(true);
		instance.saveDefaultConfig();

		this.maxHoursOffline = instance.getConfig().getInt("MaxHoursOffline", 168);
		this.defaultChunksAmountAlwaysOn = instance.getConfig().getInt("DefaultChunksAmount.AlwaysOn", 5);
		this.defaultChunksAmountOnlineOnly = instance.getConfig().getInt("DefaultChunksAmount.OnlineOnly", 50);

		// Načítanie ID a Data hodnoty blokov ako reťazec vo formáte "id:data"
		String alwaysOnBlockConfig = instance.getConfig().getString("alwaysOnBlockId", "57:0");
		String[] alwaysOnParts = alwaysOnBlockConfig.split(":");
		this.alwaysOnBlockId = parseBlockId(alwaysOnParts, 0, 57); // 57 = Diamond Block
		this.alwaysOnBlockData = parseBlockData(alwaysOnParts, 1);

		String onlineOnlyBlockConfig = instance.getConfig().getString("onlineOnlyBlockId", "42:0");
		String[] onlineOnlyParts = onlineOnlyBlockConfig.split(":");
		this.onlineOnlyBlockId = parseBlockId(onlineOnlyParts, 0, 42); // 42 = Iron Block
		this.onlineOnlyBlockData = parseBlockData(onlineOnlyParts, 1);

		// Data store a MySQL
		this.dataStore = instance.getConfig().getString("DataStore", "XML");

		this.mySqlHostname = instance.getConfig().getString("MySQL.Hostname", "localhost");
		this.mySqlPort = instance.getConfig().getString("MySQL.Port", "3306");
		this.mySqlUsername = instance.getConfig().getString("MySQL.Username", "root");
		this.mySqlPassword = instance.getConfig().getString("MySQL.Password", "");
		this.mySqlDatabase = instance.getConfig().getString("MySQL.Database", "chunkloader");
	}

	private int parseBlockId(String[] parts, int index, int defaultValue) {
		try {
			return Integer.parseInt(parts[index]);
		} catch (Exception e) {
			return defaultValue;
		}
	}

	private int parseBlockData(String[] parts, int index) {
		try {
			if (parts.length > index) {
				return Integer.parseInt(parts[index]);
			}
		} catch (Exception ignored) {}
		return 0;
	}
}
