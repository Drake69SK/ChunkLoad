package eu.avalanche7;

import eu.avalanche7.datastore.DataStoreManager;
import eu.avalanche7.datastore.IDataStore;
import eu.avalanche7.datastore.PlayerData;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.UUID;
import java.util.List;

/**
 * Integration with PlaceholderAPI for the BetterChunkLoader plugin.
 */
public class PlaceHolderIntegration extends PlaceholderExpansion {

    private final BetterChunkLoader plugin;

    public PlaceHolderIntegration(BetterChunkLoader plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String getIdentifier() {
        return "chunkloader";
    }

    @Override
    public String getAuthor() {
        List<String> authors = plugin.getDescription().getAuthors();
        return authors.isEmpty() ? "Unknown" : String.join(", ", authors);
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public String onRequest(OfflinePlayer player, String identifier) {
        if (player == null || !player.hasPlayedBefore()) {
            return null;
        }

        UUID uuid = player.getUniqueId();
        IDataStore dataStore = DataStoreManager.getDataStore();
        PlayerData playerData = dataStore.getPlayerData(uuid);

        if (playerData == null) {
            return "N/A";
        }

        switch (identifier.toLowerCase()) {
            case "chunks_total":
                int total = playerData.getAlwaysOnChunksAmount() + playerData.getOnlineOnlyChunksAmount();
                return String.valueOf(total);

            case "chunks_active":
                return String.valueOf(dataStore.getChunkLoaders(uuid).size());

            case "chunks_onlineonly_active":
                return String.valueOf(dataStore.getOnlineOnlyFreeChunksAmount(uuid));

            case "chunks_alwayson_active":
                return String.valueOf(dataStore.getAlwaysOnFreeChunksAmount(uuid));

            case "chunks_alwayson":
                return String.valueOf(playerData.getAlwaysOnChunksAmount());

            case "chunks_onlineonly":
                return String.valueOf(playerData.getOnlineOnlyChunksAmount());

            default:
                return null;
        }
    }
}
